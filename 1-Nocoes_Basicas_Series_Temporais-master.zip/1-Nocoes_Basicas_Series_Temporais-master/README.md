# Noções Básicas de Séries Temporais
## Slides e códigos da aula 1 de Ecometria Avançada - Séries Temporais na USJT.
